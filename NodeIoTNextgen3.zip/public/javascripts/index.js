function log() {
  console.log("try loggggerrr");
}
